% This script is used to extract the toxicogenomic pathways information
% from CTD Chemical�pathway enriched associations (http://ctdbase.org/downloads/;jsessionid=2681EA5B8F99F8392B8D4CBA76B70FE5).
% The code is written by Zhichao Liu at NCTR/FDA

load CTD_gene_pathways
load homologene_map
CTDgenespathways(1)=[];
genes(1)=[];
id(1)=[];
pathway_names(1)=[];
for i = 1:length(id)
    if isempty(find(human==id(i)))==0
       sky=find(human==id(i)); 
       id_r(i)=rat(sky(1));
    else
       id_r(i)=0;
    end
end
index = find(id_r==0);
CTDgenespathways(index)=[];
genes(index)=[];
id(index)=[];
pathway_names(index)=[];
id_r(index)=[];id_r=id_r';
%% gene set generation
clear i index sky
[uni_pathways,m,n]=unique(CTDgenespathways);
uni_pathway_names=pathway_names(m);
gene_num=[]; gene_sets={};
for i = 1:length(uni_pathways)
    ind=find(strcmp(uni_pathways(i),CTDgenespathways)==1);
    gene_num(i)=length(unique(id_r(ind)));
    gene_sets{i}=unique(id_r(ind));
end
clear CTDgenespathways genes human i id id_r ind m n pathway_names rat 
%% pathway cut-off 
index = find(gene_num>=200);
gene_num_cut=gene_num(index);
gene_sets_cut=gene_sets(index);
uni_pathway_names_cut=uni_pathway_names(index);
uni_pathways_cut=uni_pathways(index);
clear index gene_num gene_sets uni_pathway_names uni_pathways 
