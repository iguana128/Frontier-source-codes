function [po,index]=pog(a,b)
po = [];
if length(a)<length(b)
    index = (1:5:100)';  
    for i = 1:10:500
        a1 = a(1:i);
        b1 = b(1:i);
        aa=0;
        for j = 1:length(a1)
            if isempty(find(strcmp(a1{j},b1)==1))==0
                aa = aa+1;
            end
        end
        po=[po;aa/i];
    end
else
    index = (1:5:100)';  
    for i = 1:5:100
        a1 = a(1:i);
        b1 = b(1:i);
        aa=0;
        for j = 1:length(b1)
            if isempty(find(strcmp(b1{j},a1)==1))==0
                aa = aa+1;
            end
        end
        po=[po;aa/i];
    end
end

