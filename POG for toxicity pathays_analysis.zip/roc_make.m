function [X,Y,AUC] = roc_make(a,b)
X = []; Y=[]; AUC = 0;
%[m,n]=sort(b,'descend');
cut_off=quantile(b,0.99);
%cut_off=0.4;
labels = zeros(length(b),1);
labels(find(b>=cut_off))=1;
if isempty(find(b>=cut_off))==0
    [X,Y,T,AUC] = perfcurve(labels,a,1);
end

