function [index]=overlap(a,b)
for i=1:length(a)
    if isempty(find(b==a(i)))==0
        index(i)=find(b==a(i));
    else
        index(i)=0;
    end
end
index(find(index==0))=[];
