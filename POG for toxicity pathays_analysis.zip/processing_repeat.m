clear
%close all
%% data input
load data_collapsed_repeat
load drug_infor
%% barcode extraction
for i = 1:length(sampleNames_repeat)
    index = findstr(sampleNames_repeat{i},'_');
    barcode(i,1) = str2num(sampleNames_repeat{i}(index(end)+1:end-1));
end
%% 
for i = 1:length(barcode)
    list = find(bar_total==barcode(i));
    repeat_setting{i,1} = setting{list};
    dose_repeat(i,1) = dose(list);
    drugs_repeat{i,1} = drugs{list};
end
%% clear 
clear bar_total barcode dose drugs i index list setting sampleNames_repeat
%%
load drug_overlap
sel = [];
for i = 1:length(drugs_repeat)
    if isempty(find(strcmp(drugs_repeat{i},drug_overlap)==1))==1
       sel = [sel,i];
    end
end
data_repeat(sel,:)=[];
dose_repeat(sel)=[];
drugs_repeat(sel)=[];
repeat_setting(sel)=[];
%% mtach control
for i = 1:length(repeat_setting)
    if isempty(findstr(repeat_setting{i},'Control'))==1
       kl = findstr(repeat_setting{i},'_');
       tmp = [repeat_setting{i}(1:kl(end)),'Control'];
       lk = find(strcmp(tmp,repeat_setting)==1);
       data_repeat(i,:)=data_repeat(i,:)-data_repeat(lk,:);
    end
end
%% high dose and longest durepeation
gg = '29 day_High';
for i = 1:length(repeat_setting)
    if findstr(repeat_setting{i},gg)
       list(i)=1;
    else
       list(i)=0;
    end
end
%%
data_repeat = data_repeat(find(list==1),:);
dose_repeat = dose_repeat(find(list==1));
drugs_repeat = drugs_repeat(find(list==1),1);
repeat_setting = repeat_setting(find(list==1));
%% DEG generepeation
ll = find(ini_repeat>0.5);
data_repeat(:,ll)=[];
geneNames_repeat(ll)=[];
DEG = struct();
%% id extraction
for i = 1:length(geneNames_repeat)
    ind=findstr(geneNames_repeat{i},'_at');
    if isempty(ind)==0 & isempty(findstr(geneNames_repeat{i},'AFF'))==1
       rat_id(i)=str2num(geneNames_repeat{i}(2:ind(1)-1));
    else
        rat_id(i)=0;
    end
end
index=find(rat_id==0);
data_repeat(:,index)=[];
rat_id(index)=[];
geneNames_repeat(index)=[];
clear DEG i ind ini_repeat kl list lk ll num sel tmp   
save('repeat_data_for_similarity.mat')
