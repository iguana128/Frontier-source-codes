clear
close all
%% ROC curve generation
load rat_pairs_pathway
load single_pairs_pathway
load repeat_pairs_pathway
names=fieldnames(pairs_total_rat);
X1={};X2={};X3={};Y1={};Y2={};Y3={};AUC1=[];AUC2=[];AUC3=[];
for i=1:length(names)
    [X1{i},Y1{i},AUC1(i)] = roc_make(pairs_total_rat.(names{i}).dice,pairs_total_single.(names{i}).dice);
    [X2{i},Y2{i},AUC2(i)] = roc_make(pairs_total_rat.(names{i}).dice,pairs_total_repeat.(names{i}).dice);
    [X3{i},Y3{i},AUC3(i)] = roc_make(pairs_total_single.(names{i}).dice,pairs_total_repeat.(names{i}).dice);
end
%% sorting AUC for different pathways
AUC = [AUC1;AUC2;AUC3];
[m,n]=sort(AUC1,'descend');
pathway_rat=uni_pathway_names_cut(n);
[m,n]=sort(AUC2,'descend');
pathway_single=uni_pathway_names_cut(n);
[m,n]=sort(AUC3,'descend');
pathway_repeat=uni_pathway_names_cut(n);
% Percentage of overlapping pathway analysis
[po1,index1]=pog(pathway_rat,pathway_single);
[po2,index2]=pog(pathway_rat,pathway_repeat);
[po3,index3]=pog(pathway_single,pathway_repeat);

