clear,clc
close all
load rat_data_for_similarity
load CTD_genesets
pairs_total=struct();
for i=1:length(gene_sets_cut)
    gene_sets=gene_sets_cut{i};
    DEG=struct();
    [index]=overlap(gene_sets,rat_id);
    data_rat_sub=data_rat(:,index);
    for j=1:size(data_rat,1)
        DEG.(['drugs',num2str(j)])=find(abs(data_rat_sub(j,:))>=0.59);
    end
    Dice=[];pairs={};
    names = fieldnames(DEG);
    for ii = 1:length(names)-1
        for jj = ii+1:length(names)
            dice_t=2*length(intersect(DEG.(names{ii}),DEG.(names{jj})))/(length(DEG.(names{ii}))+length(DEG.(names{jj})));
            Dice=[Dice;dice_t];pairs=[pairs;[drugs_rat{ii},'%',drugs_rat{jj}]];
        end
    end
    pairs_total.(['gene_sets',num2str(i)]).pairs=pairs;
    pairs_total.(['gene_sets',num2str(i)]).dice=Dice;
    clear data_rat_sub
end
clear data_rat DEG Dice dice_t dose_rat drug_overlap gene_num_cut gene_sets geneNames_rat gg i ii index j jj names pairs rat_id rat_setting           
    
        
        
        
    
