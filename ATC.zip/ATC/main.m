clear
close all
% this script is used to carry out the stablity analysis for different
% therapeutic categories based the second level of WHO ATC systems
% the code was written by Zhichao Liu at NCTR/FDA

load ATC_information
drug1={};ATC1={};
for i = 1:length(ATC)
    if isempty(ATC{i})==0
       kk=findstr(ATC{i},'%');
       if isempty(kk)==0
          kk = [0 kk length(ATC{i})+1];
          for j = 1:length(kk)-1
              drug1=[drug1;drugs{i}];
              ATC1=[ATC1;ATC{i}(kk(j)+1:kk(j)+3)];
          end
       else
           drug1=[drug1;drugs{i}];
           ATC1=[ATC1;ATC{i}(1:3)];
       end
    end
    kk=[];
end
%%
uni_ATC=unique(ATC1);
for i = 1:length(uni_ATC)
    count(i)=length(find(strcmp(uni_ATC{i},ATC1)));
end
[m,n]=sort(count,'descend');
uni_ATC_rank=uni_ATC(n);
%%
drug_ATC=struct();
for i = 1:length(uni_ATC_rank)
    drug_ATC.(uni_ATC_rank{i})=unique(drug1(find(strcmp(uni_ATC_rank{i},ATC1)==1)));
    counts(i)=length(unique(drug1(find(strcmp(uni_ATC_rank{i},ATC1)==1))));
end
list=find(counts>=5);
drug_ATC_need=uni_ATC_rank(list);
drug_ATC_needed=struct();drug_list_total={};
for i = 1:length(drug_ATC_need)
    drug_ATC_needed.(drug_ATC_need{i})=drug_ATC.(drug_ATC_need{i});
    drug_list_total=[drug_list_total;drug_ATC.(drug_ATC_need{i})];
end
%% stablity calculation for ATC including drug_ATC_need ({'J01';'N06';'S01';'N05';'C01';'M01';'N03';'L01';'C10';'A10';'M02';'N02'})
[stability_rat_J01,stability_single_J01,stability_repeat_J01] = mapped_out(drug_ATC_needed.J01,drug_list_total);
[stability_rat_N06,stability_single_N06,stability_repeat_N06] = mapped_out(drug_ATC_needed.N06,drug_list_total);
[stability_rat_S01,stability_single_S01,stability_repeat_S01] = mapped_out(drug_ATC_needed.S01,drug_list_total);
[stability_rat_N05,stability_single_N05,stability_repeat_N05] = mapped_out(drug_ATC_needed.N05,drug_list_total);
[stability_rat_C01,stability_single_C01,stability_repeat_C01] = mapped_out(drug_ATC_needed.C01,drug_list_total);
[stability_rat_M01,stability_single_M01,stability_repeat_M01] = mapped_out(drug_ATC_needed.M01,drug_list_total);
[stability_rat_N03,stability_single_N03,stability_repeat_N03] = mapped_out(drug_ATC_needed.N03,drug_list_total);
[stability_rat_L01,stability_single_L01,stability_repeat_L01] = mapped_out(drug_ATC_needed.L01,drug_list_total);
[stability_rat_C10,stability_single_C10,stability_repeat_C10] = mapped_out(drug_ATC_needed.C10,drug_list_total);
[stability_rat_A10,stability_single_A10,stability_repeat_A10] = mapped_out(drug_ATC_needed.A10,drug_list_total);
[stability_rat_M02,stability_single_M02,stability_repeat_M02] = mapped_out(drug_ATC_needed.M02,drug_list_total);
[stability_rat_N02,stability_single_N02,stability_repeat_N02] = mapped_out(drug_ATC_needed.N02,drug_list_total);
total=[stability_rat_N02,stability_rat_M02,stability_rat_A10,stability_rat_C10,stability_rat_N03,stability_rat_L01,stability_rat_M01,...
    stability_rat_C01,stability_rat_N05,stability_rat_N06,stability_rat_J01,stability_rat_S01,...
    stability_single_N02,stability_single_M02,stability_single_A10,stability_single_C10,stability_single_N03,stability_single_L01,stability_single_M01,...
    stability_single_C01,stability_single_N05,stability_single_N06,stability_single_J01,stability_single_S01,...
stability_repeat_N02,stability_repeat_M02,stability_repeat_A10,stability_repeat_C10,stability_repeat_N03,stability_repeat_L01,stability_repeat_M01,...
    stability_repeat_C01,stability_repeat_N05,stability_repeat_N06,stability_repeat_J01,stability_repeat_S01];



 