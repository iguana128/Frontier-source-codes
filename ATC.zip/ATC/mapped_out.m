function [disti_rat,disti_single,disti_repeat] = mapped_out(drug_list_sub,drug_list)
load pairs_all_dice
%%
for i = 1:length(pairs_rat)
    ll = findstr(pairs_rat{i},'%');
    a = pairs_rat{i}(1:ll-1);
    b = pairs_rat{i}(ll+1:end);
    if isempty(find(strcmp(a,drug_list)==1))==0|isempty(find(strcmp(b,drug_list)==1))==0
       sky1(i)=1;
    else
       sky1(i)=0;
    end    
end
pairs_rat=pairs_rat(find(sky1==1));
rat_dice=rat_dice(find(sky1==1));
single_dice=single_dice(find(sky1==1));
repeat_dice=repeat_dice(find(sky1==1));
clear sky1
for i = 1:length(pairs_rat)
    ll = findstr(pairs_rat{i},'%');
    a = pairs_rat{i}(1:ll-1);
    b = pairs_rat{i}(ll+1:end);
    if isempty(find(strcmp(a,drug_list_sub)==1))==0&isempty(find(strcmp(b,drug_list_sub)==1))==0
       sky(i)=1;
    else
       sky(i)=0;
    end
    if isempty(find(strcmp(a,drug_list_sub)==1))==0|isempty(find(strcmp(b,drug_list_sub)==1))==0
       sky1(i)=1;
    else
       sky1(i)=0;
    end    
end
rat_dice1 = rat_dice(find((sky+sky1)==2));
single_dice1= single_dice(find((sky+sky1)==2));
repeat_dice1 = repeat_dice(find((sky+sky1)==2));
rat_dice2 = rat_dice(find((sky+sky1)==1));
single_dice2= single_dice(find((sky+sky1)==1));
repeat_dice2 = repeat_dice(find((sky+sky1)==1));
% inter_rat=mean(rat_dice1)/std(rat_dice1);
% inter_single=mean(single_dice1)/std(rat_dice1);
% inter_repeat=mean(repeat_dice1)/std(rat_dice1);
% across_rat=mean(rat_dice2)/std(rat_dice2);
% across_single=mean(single_dice2)/std(rat_dice2);
% across_repeat=mean(repeat_dice2)/std(rat_dice2);
inter_rat=mean(rat_dice1);
inter_single=mean(single_dice1);
inter_repeat=mean(repeat_dice1);
across_rat=mean(rat_dice2);
across_single=mean(single_dice2);
across_repeat=mean(repeat_dice2);
disti_rat=inter_rat/across_rat;
disti_single=inter_single/across_single;
disti_repeat=inter_repeat/across_repeat;
