function display(obj)
disp(struct(obj))
