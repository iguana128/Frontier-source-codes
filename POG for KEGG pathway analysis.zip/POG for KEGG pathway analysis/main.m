clear
close all
% this script is used to carry out KEGG pathway analysis Through DAVID web
% (https://david.ncifcrf.gov/). You needed provide a registed email to make
% it run. please fill your email in line 22. Furthermore, to make it run correctly,
% you need follow the notes of matlab code for DAVID
% (https://david.ncifcrf.gov/content.jsp?file=WS.html) to make setting in
% your local environment
% the code was written by Zhichao Liu at NCTR/FDA

%% load DEG (top/down 200 genes) in testing systems  
load rat_invitro_DEG_400
%load single_DEG_400
%load repeat_DEG_400
%% reformat
names = fieldnames(DEG);
for i = 1:length(names)
    sky1{i}=[];
    sky = DEG.(names{i});
    tt = gene_names(sky);
    for j = 1:length(tt)
        sky1{i} = [sky1{i},num2str(tt(j)),','];
    end
end

%% link to DAVID web service to carray out functional analysis
obj = DAVIDWebService;
authenticate(obj,'example@fda.hhs.gov') % replace the email with your registered email address
getConversionTypes(obj)
for jj = 1:length(names)
    inputIds = sky1{jj}(1:end-1);
    idType = 'ENTREZ_GENE_ID';
    listName = 'Correlated genes';
    listType = 0;
    addList(obj, inputIds, idType, listName, listType)
    chartReport=getChartReport(obj,0.1,2);

%% extract the KEGG pathways and statistics
    benjamini = []; bonferroni = []; termName = {};
    for i = 1:length(chartReport)
        category = chartReport(i).categoryName;
        if findstr(category,'KEGG_PATHWAY')
           if str2num(chartReport(i).benjamini)<=0.05
              benjamini = [benjamini;str2num(chartReport(i).benjamini)];
              bonferroni  =[bonferroni; str2num(chartReport(i).bonferroni)];
              termName  = [termName;chartReport(i).termName];
           end
        end
    end
    pathways.(names{jj})= termName;
    if jj == 50
        save('results.mat','pathways');
    end
end

